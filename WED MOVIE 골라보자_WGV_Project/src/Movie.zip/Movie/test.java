package Movie;

public class test {
	public static void main(String[] args) {
		new Movie();
	}
}
